﻿public class TrafficLight
{
    public int Duration { get; }
    public string State { get; set; } // Make the setter public

    public TrafficLight(int duration)
    {
        Duration = duration;
        State = "Red"; // Default state
    }

    public void ChangeState(string newState)
    {
        State = newState;
    }
}
