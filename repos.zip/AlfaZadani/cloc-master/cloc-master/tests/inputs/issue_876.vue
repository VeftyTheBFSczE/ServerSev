<template>
    <div v-loading="loading">
        <div>aaa</div>
    </div>
</template>
<script>
import(menCommonConstant } from '@/utils/menConstant'
// test
export detault,
    name: 'SpecProgramClientNotice',
    components: {
        vxeTable, //table
        menClientInout
    }
</script>
<style lang="scss" scoped></style>
