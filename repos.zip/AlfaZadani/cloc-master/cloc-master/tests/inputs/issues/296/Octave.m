% from http://www.roesler-ac.de/wolfram/hello.htm
#Hello World in Octave (http://www.octave.org/)
printf("Hello World\n");
