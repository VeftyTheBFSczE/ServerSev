// hello.C
#include <iostream>
int main ()
{
    std::cout << "yo" << std::endl;  // comment 1
}
