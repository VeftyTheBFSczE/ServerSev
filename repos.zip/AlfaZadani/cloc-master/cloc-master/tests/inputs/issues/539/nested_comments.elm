a = 1
{- a multiline comment
   {- can be nested -}
-}
b = 2
