foo: = "*/*"
a: = 10
b: = 20
foo: = "*/*"

/*
 a comment
 */

foo: = `*/*`
a: = 10
b: = 20
foo: = `*/*`
