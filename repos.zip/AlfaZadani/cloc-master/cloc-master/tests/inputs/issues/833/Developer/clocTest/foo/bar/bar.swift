struct bar { }
