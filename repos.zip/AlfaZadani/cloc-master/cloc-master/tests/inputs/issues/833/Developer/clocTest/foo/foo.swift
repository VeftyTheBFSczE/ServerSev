struct foo {
}
