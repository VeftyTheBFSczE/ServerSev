-- another instance
-- single line comment

--[[
multi 
line 
comment
]]

--[[
also a comment
--]]

print("hello 2, world")
print([[not a comment]])
